# System Health Utility

Cross-platform Python client that performs checks and reports to the backend only when a change is detected.

## Usage
```
python -m utility.main --once --api http://localhost:8000 --token devtoken
python -m utility.main --daemon --api http://localhost:8000 --token devtoken --min 15 --max 60
```

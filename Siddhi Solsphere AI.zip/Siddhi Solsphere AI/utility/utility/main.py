import argparse
from .daemon import run_once, run_daemon

def main():
    p = argparse.ArgumentParser(description="System Health Utility")
    p.add_argument("--api", required=True, help="API base URL, e.g., http://localhost:8000")
    p.add_argument("--token", required=True, help="Bearer token")
    p.add_argument("--once", action="store_true", help="Run one-shot and exit")
    p.add_argument("--daemon", action="store_true", help="Run as a daemon loop")
    p.add_argument("--min", type=int, default=15, help="Min minutes between checks (daemon)")
    p.add_argument("--max", type=int, default=60, help="Max minutes between checks (daemon)")
    args = p.parse_args()

    if args.once:
        changed = run_once(args.api, args.token)
        print("Reported change" if changed else "No change detected")
    elif args.daemon:
        run_daemon(args.api, args.token, args.min, args.max)
    else:
        p.error("Specify either --once or --daemon")

if __name__ == "__main__":
    main()

import time, random, hashlib, json, requests
from datetime import datetime, timezone
from .config import machine_id, os_name, hostname, last_hash, save_hash
from .checks import check_disk_encryption, check_os_updates, check_antivirus, check_sleep_settings

def gather_checks():
    return {
        "disk_encryption": check_disk_encryption(),
        "os_updates": check_os_updates(),
        "antivirus": check_antivirus(),
        "sleep_settings": check_sleep_settings(),
    }

def state_payload():
    checks = gather_checks()
    payload = {
        "machine_id": machine_id(),
        "hostname": hostname(),
        "os": os_name(),
        "checks": checks,
        "ts": datetime.now(timezone.utc).isoformat()
    }
    return payload

def payload_hash(payload: dict) -> str:
    return hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()

def post_update(api_base: str, token: str, payload: dict):
    url = f"{api_base.rstrip('/')}/api/v1/ingest"
    headers = {"Authorization": f"Bearer {token}"}
    resp = requests.post(url, json=payload, headers=headers, timeout=15)
    resp.raise_for_status()

def run_once(api_base: str, token: str) -> bool:
    payload = state_payload()
    h = payload_hash(payload)
    if h != last_hash():
        post_update(api_base, token, payload)
        save_hash(h)
        return True
    return False

def run_daemon(api_base: str, token: str, min_minutes=15, max_minutes=60):
    while True:
        try:
            _ = run_once(api_base, token)
            sleep_mins = random.randint(min_minutes, max_minutes)
        except Exception:
            sleep_mins = min_minutes
        time.sleep(sleep_mins * 60)

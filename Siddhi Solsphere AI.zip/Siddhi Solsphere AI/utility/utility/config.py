import json, os, platform, socket, uuid, pathlib, hashlib

STATE_DIR = pathlib.Path.home() / ".syshealth"
STATE_DIR.mkdir(exist_ok=True)

STATE_FILE = STATE_DIR / "state.json"
HASH_FILE = STATE_DIR / "last_hash.txt"

def machine_id() -> str:
    nid = uuid.getnode()
    host = socket.gethostname()
    basis = f"{host}-{nid}"
    return hashlib.sha256(basis.encode()).hexdigest()[:16]

def load_state():
    if STATE_FILE.exists():
        return json.loads(STATE_FILE.read_text())
    return {}

def save_state(data):
    STATE_FILE.write_text(json.dumps(data, indent=2))

def last_hash():
    return HASH_FILE.read_text().strip() if HASH_FILE.exists() else ""

def save_hash(h: str):
    HASH_FILE.write_text(h)

def os_name():
    return f"{platform.system()} {platform.release()}"

def hostname():
    return socket.gethostname()

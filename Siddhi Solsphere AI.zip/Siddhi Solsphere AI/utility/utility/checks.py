import subprocess, platform, re, json, shutil
from typing import Dict, Any

def run(cmd: str) -> str:
    try:
        out = subprocess.check_output(cmd, stderr=subprocess.STDOUT, shell=True, text=True, timeout=25)
        return out.strip()
    except Exception as e:
        return f"ERR:{e}"

def check_disk_encryption() -> Dict[str, Any]:
    system = platform.system().lower()
    result = {"ok": None, "details": ""}
    if system == "windows":
        out = run("manage-bde -status")
        encrypted = ("Percentage Encrypted: 100%" in out) or ("Conversion Status: Fully Encrypted" in out)
        result["ok"] = bool(encrypted)
        result["details"] = "BitLocker status parsed"
    elif system == "darwin":
        out = run("/usr/bin/fdesetup status")
        encrypted = ("FileVault is On." in out) or ("Encryption in progress" in out)
        result["ok"] = bool(encrypted)
        result["details"] = "FileVault status parsed"
    else:
        lsblk = run("lsblk -o NAME,TYPE,MOUNTPOINT,FSTYPE | tr -s ' '")
        encrypted = any((("crypt" in line) or ("luks" in line.lower())) and ("/" in line) for line in lsblk.splitlines())
        result["ok"] = bool(encrypted)
        result["details"] = "Heuristic via lsblk"
    return result

def check_os_updates() -> Dict[str, Any]:
    system = platform.system().lower()
    result = {"ok": None, "details": "", "installed_version": platform.version(), "updates_available": None}
    if system == "windows":
        ps = ("powershell -NoProfile -Command "
              "$s=(New-Object -ComObject Microsoft.Update.Session).CreateUpdateSearcher();"
              "($s.Search('IsInstalled=0 and Type=\'Software\'')).Updates.Count)")
        out = run(ps)
        try:
            m = re.findall(r"\d+", out)
            cnt = int(m[0]) if m else 0
        except Exception:
            cnt = None
        result["updates_available"] = cnt
        result["ok"] = (cnt == 0) if cnt is not None else None
        result["details"] = "Windows Update COM search"
    elif system == "darwin":
        out = run("/usr/sbin/softwareupdate -l")
        has_updates = ("No new software available." not in out) and (not out.startswith("ERR:"))
        result["updates_available"] = None if out.startswith("ERR:") else (1 if has_updates else 0)
        result["ok"] = False if has_updates else True
        result["details"] = "softwareupdate -l parsed"
    else:
        if shutil.which("apt-get"):
            out = run("apt-get -s upgrade | grep -c '^Inst ' || true")
            try:
                cnt = int(out.strip())
            except Exception:
                cnt = None
            result["updates_available"] = cnt
            result["ok"] = (cnt == 0) if cnt is not None else None
            result["details"] = "apt-get simulated upgrade"
        elif shutil.which("dnf"):
            out = run("dnf -q check-update | wc -l")
            try:
                cnt = int(out.strip())
            except Exception:
                cnt = None
            result["updates_available"] = cnt
            result["ok"] = (cnt == 0) if cnt is not None else None
            result["details"] = "dnf check-update"
        else:
            result["details"] = "Unknown package manager"
            result["ok"] = None
    return result

def check_antivirus() -> Dict[str, Any]:
    system = platform.system().lower()
    result = {"ok": None, "details": "", "product": None, "running": None}
    if system == "windows":
        ps = ("powershell -NoProfile -Command "
              "Get-MpComputerStatus | "
              "Select-Object AMServiceEnabled,AntivirusEnabled,RealTimeProtectionEnabled | ConvertTo-Json)")
        out = run(ps)
        try:
            data = json.loads(out)
            enabled = data.get("AntivirusEnabled") or data.get("RealTimeProtectionEnabled") or data.get("AMServiceEnabled")
            result["ok"] = bool(enabled)
            result["running"] = bool(enabled)
            result["product"] = "Microsoft Defender (or 3rd-party if registered)"
            result["details"] = "Get-MpComputerStatus"
        except Exception:
            result["details"] = out[:200]
            result["ok"] = None
    elif system == "darwin":
        out = run("pgrep -fl 'symantec|defender|crowdstrike|falcon|mcafee|sophos|bitdefender|avast|avg|clamd' || true")
        running = (len(out.strip()) > 0) and (not out.startswith("ERR:"))
        result["ok"] = running
        result["running"] = running
        result["product"] = "Detected" if running else "None detected"
        result["details"] = "pgrep heuristic"
    else:
        out = run("systemctl is-active clamd 2>/dev/null || systemctl is-active clamav-daemon 2>/dev/null || true")
        running = "active" in out
        result["ok"] = running
        result["running"] = running
        result["product"] = "ClamAV" if running else "None detected"
        result["details"] = "systemd check"
    return result

def check_sleep_settings() -> Dict[str, Any]:
    system = platform.system().lower()
    result = {"ok": None, "details": "", "timeout_minutes": None}
    try:
        if system == "windows":
            out = run("powercfg /q")
            m = re.search(r"VIDEOIDLE[\s\S]*?AC Power Setting Index:\s*(\d+)", out)
            minutes = int(int(m.group(1)) / 60) if m else None
            result["timeout_minutes"] = minutes
            result["ok"] = (minutes is not None and minutes <= 10)
            result["details"] = "powercfg /q parsed"
        elif system == "darwin":
            out = run("/usr/bin/pmset -g")
            m = re.search(r"displaysleep\s+(\d+)", out)
            minutes = int(m.group(1)) if m else None
            result["timeout_minutes"] = minutes
            result["ok"] = (minutes is not None and minutes <= 10)
            result["details"] = "pmset parsed (displaysleep)"
        else:
            out = run("gsettings get org.gnome.settings-daemon.plugins.power sleep-inactive-ac-timeout || echo 0")
            nums = re.findall(r"\d+", out)
            minutes = int(int(nums[0]) / 60) if nums else None
            result["timeout_minutes"] = minutes
            result["ok"] = (minutes is not None and minutes <= 10)
            result["details"] = "gsettings parsed"
    except Exception as e:
        result["details"] = f"ERR:{e}"
        result["ok"] = None
    return result

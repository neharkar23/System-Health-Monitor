# System Health Suite
(See repo for full details. Quickstart in each subfolder.)

- `utility/` — Python cross-platform client (Windows/macOS/Linux)
- `backend/` — FastAPI + SQLite API server
- `frontend/` — React + Vite + TS + Tailwind dashboard
- `docker-compose.yml` — Dev convenience

## Quick Start
### Backend
```
cd backend
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

### Frontend
```
cd frontend
npm install
npm run dev
```

### Utility
```
cd utility
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python -m utility.main --once --api http://localhost:8000 --token devtoken
python -m utility.main --daemon --api http://localhost:8000 --token devtoken --min 15 --max 60
```

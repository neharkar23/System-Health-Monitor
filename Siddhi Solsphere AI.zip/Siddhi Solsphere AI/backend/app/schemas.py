from pydantic import BaseModel
from typing import Optional, Any, Dict
from datetime import datetime

class StatusPayload(BaseModel):
    machine_id: str
    hostname: str
    os: str
    checks: Dict[str, Any]
    ts: datetime

class MachineOut(BaseModel):
    machine_id: str
    os: Optional[str]
    hostname: Optional[str]
    last_checkin: Optional[datetime]
    checks: Dict[str, Any]

    class Config:
        from_attributes = True

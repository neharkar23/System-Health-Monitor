from sqlalchemy import Column, Integer, String, DateTime, JSON, func, Index
from .database import Base

class Machine(Base):
    __tablename__ = "machines"
    id = Column(Integer, primary_key=True, index=True)
    machine_id = Column(String, unique=True, index=True, nullable=False)
    os = Column(String, index=True)
    hostname = Column(String)
    last_checkin = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    status = Column(JSON)  # latest status payload

Index("ix_machine_os", Machine.os)

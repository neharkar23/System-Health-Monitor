

from fastapi import FastAPI, Depends, HTTPException, Query, Response
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import select
from typing import List, Optional
from datetime import datetime
import csv
from io import StringIO
import os

from .database import Base, engine, get_db
from .models import Machine
from .schemas import StatusPayload, MachineOut

Base.metadata.create_all(bind=engine)

app = FastAPI(title="System Health API", version="1.0.0")

# CORS setup
origins = os.getenv("CORS_ORIGINS", "*")
allow_origins = origins.split(",") if origins else ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=allow_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# -----------------------
# POST /ingest
# -----------------------
@app.post("/api/v1/ingest")
def ingest_status(payload: StatusPayload, db: Session = Depends(get_db)):
    stmt = select(Machine).where(Machine.machine_id == payload.machine_id)
    existing = db.execute(stmt).scalar_one_or_none()

    # ensure datetime is JSON serializable
    item = {
        "machine_id": payload.machine_id,
        "os": payload.os,
        "hostname": payload.hostname,
        "status": payload.model_dump(mode="json"),
        "last_checkin": datetime.utcnow(),
    }

    if existing:
        for k, v in item.items():
            setattr(existing, k, v)
        db.add(existing)
    else:
        db.add(Machine(**item))

    db.commit()
    return {"ok": True}

# -----------------------
# GET /machines
# -----------------------
@app.get("/api/v1/machines", response_model=List[MachineOut])
def list_machines(
    db: Session = Depends(get_db),
    os_filter: Optional[str] = Query(None, description="Filter by OS contains value"),
    has_issues: Optional[bool] = Query(None, description="Only machines with flagged issues"),
):
    stmt = select(Machine)
    rows = db.execute(stmt).scalars().all()

    out = []
    for m in rows:
        checks = m.status.get("checks", {}) if m.status else {}
        if os_filter and (m.os or "").lower().find(os_filter.lower()) == -1:
            continue
        if has_issues is not None:
            def has_problem(obj):
                if isinstance(obj, dict):
                    if "ok" in obj and obj["ok"] is False:
                        return True
                    return any(has_problem(v) for v in obj.values())
                if isinstance(obj, list):
                    return any(has_problem(v) for v in obj)
                return False
            problems = has_problem(checks)
            if has_issues != problems:
                continue
        out.append(MachineOut(
            machine_id=m.machine_id,
            os=m.os,
            hostname=m.hostname,
            last_checkin=m.last_checkin,
            checks=checks
        ))
    return out

# -----------------------
# GET /machines/{id}
# -----------------------
@app.get("/api/v1/machines/{machine_id}", response_model=MachineOut)
def get_machine(machine_id: str, db: Session = Depends(get_db)):
    stmt = select(Machine).where(Machine.machine_id == machine_id)
    m = db.execute(stmt).scalar_one_or_none()
    if not m:
        raise HTTPException(status_code=404, detail="Not found")
    checks = m.status.get("checks", {}) if m.status else {}
    return MachineOut(
        machine_id=m.machine_id, os=m.os, hostname=m.hostname,
        last_checkin=m.last_checkin, checks=checks
    )

# -----------------------
# GET /machines.csv
# -----------------------
@app.get("/api/v1/machines.csv")
def export_csv(db: Session = Depends(get_db)):
    stmt = select(Machine)
    rows = db.execute(stmt).scalars().all()
    sio = StringIO()
    import json as _json
    writer = csv.writer(sio)
    writer.writerow(["machine_id", "hostname", "os", "last_checkin", "checks_json"])
    for m in rows:
        writer.writerow([m.machine_id, m.hostname, m.os, m.last_checkin, _json.dumps(m.status or {})])
    return Response(content=sio.getvalue(), media_type="text/csv")



import React, { useEffect, useState } from 'react'
import MachinesTable from './components/MachinesTable'

const API = import.meta.env.VITE_API_BASE || 'http://localhost:8000'

export type Checks = Record<string, any>
export type Machine = {
  machine_id: string
  os?: string
  hostname?: string
  last_checkin?: string
  checks: Checks
}

export default function App() {
  const [machines, setMachines] = useState<Machine[]>([])
  const [osFilter, setOsFilter] = useState('')
  const [issueOnly, setIssueOnly] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function load() {
    setLoading(true)
    setError(null)
    try {
      const params = new URLSearchParams()
      if (osFilter) params.set('os_filter', osFilter)
      if (issueOnly) params.set('has_issues', 'true')
      const res = await fetch(`${API}/api/v1/machines?${params.toString()}`)
      const data = await res.json()
      setMachines(data)
    } catch (e:any) {
      setError(e?.message || 'Failed to load')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [osFilter, issueOnly])

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">System Health Admin</h1>
          <p className="text-sm text-gray-500">Latest check-ins and configuration issues</p>
        </div>
        <button onClick={load} className="px-4 py-2 rounded-2xl bg-black text-white shadow">
          Refresh
        </button>
      </header>

      <div className="card">
        <div className="flex gap-3 items-end mb-4">
          <div className="flex flex-col">
            <label className="text-xs text-gray-600">Filter by OS</label>
            <input
              value={osFilter}
              onChange={e => setOsFilter(e.target.value)}
              placeholder="windows / darwin / linux"
              className="border rounded-lg px-3 py-2"
            />
          </div>
          <label className="flex items-center gap-2">
            <input type="checkbox" checked={issueOnly} onChange={e => setIssueOnly(e.target.checked)} />
            <span>Only machines with issues</span>
          </label>
        </div>

        {loading && <div>Loading...</div>}
        {error && <div className="text-red-600">{error}</div>}
        {!loading && !error && <MachinesTable machines={machines} />}
      </div>
    </div>
  )
}

import React from 'react'
import type { Machine } from '../App'

function Badge({ok, label}:{ok:boolean|null, label:string}) {
  let cls = ok === true ? 'ok' : ok === false ? 'err' : 'warn'
  return <span className={`badge ${cls}`}>{label}</span>
}

function summarize(check:any) {
  if (!check) return '—'
  if (typeof check === 'object') {
    if ('ok' in check && 'details' in check) {
      return `${check.ok ? 'OK' : 'Issue'} • ${check.details}`
    }
  }
  return JSON.stringify(check)
}

export default function MachinesTable({machines}:{machines:Machine[]}) {
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full text-sm">
        <thead>
          <tr className="text-left text-gray-500 border-b">
            <th className="py-2 pr-4">Machine</th>
            <th className="py-2 pr-4">OS</th>
            <th className="py-2 pr-4">Last Check-in</th>
            <th className="py-2 pr-4">Disk Encryption</th>
            <th className="py-2 pr-4">OS Updates</th>
            <th className="py-2 pr-4">Antivirus</th>
            <th className="py-2 pr-4">Sleep ≤10m</th>
          </tr>
        </thead>
        <tbody>
          {machines.map(m => {
            const ce = m.checks?.disk_encryption
            const cu = m.checks?.os_updates
            const ca = m.checks?.antivirus
            const cs = m.checks?.sleep_settings
            return (
              <tr key={m.machine_id} className="border-b">
                <td className="py-3 pr-4">
                  <div className="font-medium">{m.hostname || '—'}</div>
                  <div className="text-gray-500">{m.machine_id}</div>
                </td>
                <td className="py-3 pr-4">{m.os}</td>
                <td className="py-3 pr-4">{m.last_checkin ? new Date(m.last_checkin).toLocaleString() : '—'}</td>
                <td className="py-3 pr-4">
                  <Badge ok={ce?.ok ?? null} label={ce?.ok ? 'Encrypted' : 'Not Encrypted'} />
                  <div className="text-gray-500">{summarize(ce)}</div>
                </td>
                <td className="py-3 pr-4">
                  <Badge ok={cu?.ok ?? null} label={cu?.ok ? 'Up to date' : 'Updates pending'} />
                  <div className="text-gray-500">{summarize(cu)}</div>
                </td>
                <td className="py-3 pr-4">
                  <Badge ok={ca?.ok ?? null} label={ca?.ok ? 'AV active' : 'No AV'} />
                  <div className="text-gray-500">{summarize(ca)}</div>
                </td>
                <td className="py-3 pr-4">
                  <Badge ok={cs?.ok ?? null} label={cs?.ok ? 'OK' : 'Too High'} />
                  <div className="text-gray-500">{summarize(cs)}</div>
                </td>
              </tr>
            )
          })}
        </tbody>
      </table>
      {machines.length === 0 && <div className="text-center text-gray-500 py-10">No machines yet.</div>}
    </div>
  )
}
